# Dűne – Interaktív weboldal

##  Téma bemutatása
A weboldal Frank Herbert legendás **Dűne** című sci-fi regénysorozatát mutatja be.  
A cél egy rövid, informatív és interaktív ismertető készítése a Dűne-univerzumról, ahol a látogató különböző feladatokon keresztül fedezheti fel a könyvek világát.  
A weboldal három részből áll, amelyek a sorozat különböző korszakaival foglalkoznak.

---

## Felhasznált technológiák
- **HTML5** – az oldalak szerkezetének kialakításához  
- **CSS3** – az oldalak megjelenésének formázásához  
- **JavaScript (ES6)** – az interaktív elemek és logikai műveletek megvalósításához  

---

## A weboldal felépítése
A projekt **3 különálló HTML-oldalból** áll, amelyek egymással navigációs menüvel kapcsolódnak össze.

1. **`1_Dune.html`** – A Dűne (1965)  
   - Téma: az első regény és a házak bemutatása  
   - Tartalom: rövid ismertető és egy interaktív „**Házválasztó**”  
   - **Függvény:** `hazValaszto(batorsag)`  
     - Bekéri a felhasználó bátorságszintjét (0–10) és ennek alapján meghatározza, melyik házhoz tartozna (Harkonnen, Atreides, Bene Gesserit, Fremen).  
     - Ha a felhasználó Bene Gesserit házba kerül és férfi nemű, külön üzenetet kap, hogy a császári testőrséghez tartozik.

2. **`2_MessiasGyermekei.html`** – Dűne Messiás (1969) & Dűne Gyermekei (1976)  
   - Téma: a hatalom, prófécia és örökség kérdései  
   - Tartalom: rövid ismertető és két interaktív feladat  
   - **Függvények:**  
     - `hazValasztoNemmel(batorsag, nem)` – módosított házválasztó, figyelembe veszi a nemet is  
     - `erdekessegKivalaszto()` – egyszerű logikai függvény, amely véletlenszerű érdekességet ad vissza a könyvből  

3. **`3_IstencsaszaraEretnekeiKaptalanhaz.html`** – Dűne Istencsászára (1981), Eretnekei (1984), Káptalanház (1985)  
   - Téma: a hatalom filozófiája, vallás és emberiség jövője  
   - Tartalom: ismertető és két elemző interaktív funkció  
   - **Függvények:**  
     - `olvasottKonyvekSzama()` – megszámolja, hány könyvet olvasott már a felhasználó (→ **számlálás tétel**)  
     - `legjobbKonyv()` – megkeresi a legmagasabb értékelésű könyvet (→ **maximum keresés tétel**)  

---

## 🔢 Programozási tételek és elemek
A weboldalon megvalósulnak az alapvető programozási elemek:
- **Aritmetikai műveletek** (pl. értékelések elemzése)
- **Logikai műveletek és elágazások** (if–else szerkezetek)
- **Ciklusok és tömbök** (adatok feldolgozása)
- **Függvények**, köztük **paraméteres** is
- **Programozási tételek:**
  - Összegzés / számlálás  
  - Maximum keresés  

---

## 📘 Összefoglalás
A projekt célja egy **tematikus, oktatási célú** weboldal létrehozása, amely:
- röviden bemutatja a Dűne-univerzum fő részeit,  
- interaktív módon vonja be a felhasználót,  
- és demonstrálja a **JavaScript** alapvető vezérlési szerkezeteinek és tételeinek használatát.

---

**Készítette:**  
*Kulcsár Balázs*  
**Téma:** *A Dűne-univerzum bemutatása és interaktív elemzése*