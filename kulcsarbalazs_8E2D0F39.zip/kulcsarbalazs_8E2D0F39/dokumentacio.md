# Dokumentáció: Dűne (1965) HTML oldal

## Leírás
Ezzek a HTML oldalak Frank Herbert *Dűne & Messiása & gyermekei & Istencsászára & eretnekei & Káptalanház* című regényét mutatja be röviden, magyar nyelven. Tartalmaz egy navigációs menüt a Dűne-sorozat további részeihez, valamint egy fő tartalmi blokkot, amely ismerteti a regény fő témáit, karaktereit, házait és érdekességeket.SSS

## Főbb elemek

- `<nav>`: Navigációs menü három linkkel a Dűne könyvsorozat más köteteihez.
- `<main>`: Az oldal fő tartalma:
  - Címsor (`<h1>`) a könyv címével.
  - Kép a borítóról (`<img>`).
  - Bevezető és ismertető bekezdések.
  - Témakörök felsorolása (`<ul>`), mint pl. főbb témák, karakterek, házak, érdekességek.
  - Elválasztó vonalak (`<hr>`) a szakaszok között.

## Egyéb információk
- A dokumentum UTF-8 karakterkódolást és mobilbarát nézetet használ.
- Külső CSS fájl (`style.css`) hivatkozás található a fejléchez.
- A szöveg magyar nyelvű és jól strukturált, könnyen bővíthető vagy módosítható.

## Használat
Ez a HTML oldal bemutatóként szolgálhat irodalmi ismertetők, rajongói oldalak vagy iskolai projektek számára.
