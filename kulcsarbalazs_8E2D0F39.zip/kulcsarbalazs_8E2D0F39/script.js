// 1_Dune.html 

function hazValaszto(batorsag, nem) {
  let haz = "";

  if (batorsag >= 0 && batorsag <= 4) {
    haz = "Harkonnen";
  } else if (batorsag >= 5 && batorsag <= 6) {
    haz = "Atreides ház";
  } else if (batorsag >= 7 && batorsag <= 8) {
    if (nem.toLowerCase() === "férfi" || nem.toLowerCase() === "ferfi") {
      haz = "Császári Testőrség tartozol. (Nem számít háznak.)";
    } else if (nem.toLowerCase() === "nő" || nem.toLowerCase() === "no") {
      haz = "Bene Gesserit-hez tartozol. (Nem számít háznak.)";
    } else {
      haz = "Ismeretlen érték.";
    }
  } else if (batorsag >= 9 && batorsag <= 10) {
    haz = "Fremeen-ekhez tartozol. (Nem számít háznak.)";
  } else {
    haz = "Ismeretlen érték – csak 0 és 10 közötti számot adj meg!";
  }

  document.getElementById("hazEredmeny").innerText =
    "A bátorságod és nemed alapján te a(z) " + haz + " házhoz tartoznál!";
}

// 2_MessiasGyermekei.html 

function szamoldOssze() {
  const checkboxok = document.querySelectorAll("input[name='kedvenc']:checked");
  const darab = checkboxok.length;
  document.getElementById("kedvencEredmeny").innerText =
    "Összesen " + darab + " kedvenc szereplőt választottál.";
}

function konyvErtekeles() {
  const pont = Number(document.getElementById("ertekeles").value);
  let uzenet = "";
  if (pont >= 8) uzenet = "Kiemelkedő értékelés!";
  else if (pont >= 5) uzenet = "Átlagos értékelés.";
  else uzenet = "Nem tetszett a könyv.";

  document.getElementById("ertekelesEredmeny").innerText = uzenet;
}

// 3_IstencsaszaraEretnekeiKaptalanhaz.html

function olvasottKonyvekSzama() {
  const checkboxok = document.querySelectorAll("input[name='konyv']:checked");
  const osszes = checkboxok.length;
  document.getElementById("olvasottEredmeny").innerText =
    "Összesen " + osszes + " Dűne-könyvet olvastál a 6-ból.";
}

function legjobbKonyv() {
  const ertekelesek = [
    Number(document.getElementById("dune1").value),
    Number(document.getElementById("dune2").value),
    Number(document.getElementById("dune3").value),
    Number(document.getElementById("dune4").value),
    Number(document.getElementById("dune5").value),
    Number(document.getElementById("dune6").value)
  ];

  const cimek = [
    "Dűne",
    "Dűne Messiás",
    "Dűne Gyermekei",
    "Dűne Istencsászára",
    "Dűne Eretnekei",
    "Dűne Káptalanház"
  ];

  let maxIndex = 0;
  for (let i = 1; i < ertekelesek.length; i++) {
    if (ertekelesek[i] > ertekelesek[maxIndex]) {
      maxIndex = i;
    }
  }

  document.getElementById("legjobbEredmeny").innerText =
    "A legjobbnak értékelt könyv: " +
    cimek[maxIndex] +
    " (" +
    ertekelesek[maxIndex] +
    "/10)";
}
